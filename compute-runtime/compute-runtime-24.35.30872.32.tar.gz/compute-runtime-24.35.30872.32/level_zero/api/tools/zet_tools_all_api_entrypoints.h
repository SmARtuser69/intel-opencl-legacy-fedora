/*
 * Copyright (C) 2022 Intel Corporation
 *
 * SPDX-License-Identifier: MIT
 *
 */

#pragma once
#include "zet_debug_api_entrypoints.h"
#include "zet_metric_api_entrypoints.h"
#include "zet_module_api_entrypoints.h"