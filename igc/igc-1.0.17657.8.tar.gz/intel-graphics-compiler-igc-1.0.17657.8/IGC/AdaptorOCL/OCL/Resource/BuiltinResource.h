/*========================== begin_copyright_notice ============================

Copyright (C) 2017-2021 Intel Corporation

SPDX-License-Identifier: MIT

============================= end_copyright_notice ===========================*/

//{{NO_DEPENDENCIES}}
// Used by BuiltinResource.rc
//
#define OCL_BC_START                    120
#define OCL_BC_32                       120
#define OCL_BC_64                       121
#define OCL_BC                          122
#define OCL_BC_RS                       123
#define OCL_BC_END                      124

