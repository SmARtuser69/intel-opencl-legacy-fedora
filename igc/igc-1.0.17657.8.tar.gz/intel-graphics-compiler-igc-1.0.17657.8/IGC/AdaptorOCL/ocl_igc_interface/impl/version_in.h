/*========================== begin_copyright_notice ============================

Copyright (C) 2021 Intel Corporation

SPDX-License-Identifier: MIT

============================= end_copyright_notice ===========================*/


#ifndef IGC_VERSION_H
#define IGC_VERSION_H

#cmakedefine IGC_REVISION "${IGC_REVISION}"

#endif
